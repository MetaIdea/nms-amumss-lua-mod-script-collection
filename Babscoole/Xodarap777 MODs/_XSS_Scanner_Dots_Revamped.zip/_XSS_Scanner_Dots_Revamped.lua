NMS_MOD_DEFINITION_CONTAINER = 
{
    ["MOD_FILENAME"]  = "_XSS_Scanner_Dots_Revamped.pak",
    ["MOD_AUTHOR"]    = "WhoTnT",
    ["LUA_AUTHOR"]    = "Babscoole",
    ["NMS_VERSION"]   = "5.29",
    ["MODIFICATIONS"] = 
    {
    }
}